# CMGT Coin Miner

Van Dani Verschoor (1007501).

Ik heb de opdracht in Elixir gemaakt.

Belangrijke bestanden:

`test/mod10_tests.exs` -- Unit tests hashing algoritme.

`lib/chain/mod10.ex` -- Implementatie hashing algoritme.

`lib/chain/api.ex` -- Implementatie webserver communicatie.

`lib/chain.ex` -- Implementatie zoeken van nonces.

## Externe Libraries

`jason` -- Data van en naar JSON strings vertalen.

`HTTPoison` -- HTTP communicatie.

## Gebruikte Ingebouwde Modules

`:crypto` -- Gebruikt voor SHA256 hashing.

`:logger` -- Crash logs.
