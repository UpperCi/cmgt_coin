defmodule ApiTest do
  use ExUnit.Case
  alias Chain.Api
  doctest Chain
end
